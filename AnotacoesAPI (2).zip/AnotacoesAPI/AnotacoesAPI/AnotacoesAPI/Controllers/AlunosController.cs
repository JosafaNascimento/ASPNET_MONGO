﻿using AnotacoesAPI.Models;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;

namespace AnotacoesAPI.Controllers
{
    public class AlunosController : Controller
    {
        public IActionResult Index()
        {
            MongoDbContext dbContext = new MongoDbContext();

            List<Aluno> listaAlunos = dbContext.Alunos.Find(m => true).ToList();

            return View(listaAlunos);
        }

        [HttpGet]
        public IActionResult Edit(Guid id)
        {
            MongoDbContext dbContext = new MongoDbContext();
            var entity = dbContext.Alunos.Find(m => m.Id == id).FirstOrDefault();

            return View(entity);
        }

        [HttpPost]
        public IActionResult Edit(Aluno entity)
        {
            MongoDbContext dbContext = new MongoDbContext();

            //voce pode usar UpdateOne para ter um desempenho melhor
            dbContext.Alunos.ReplaceOne(m => m.Id == entity.Id, entity);

            return View(entity);
        }

        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Add(Aluno entity)
        {
            MongoDbContext dbContext = new MongoDbContext();

            entity.Id = Guid.NewGuid();

            dbContext.Alunos.InsertOne(entity);

            return RedirectToAction("Index", "Alunos");
        }

        [HttpGet]
        public IActionResult Delete(Guid id)
        {
            MongoDbContext dbContext = new MongoDbContext();

            dbContext.Alunos.DeleteOne(m => m.Id == id);

            return RedirectToAction("Index", "Alunos");
        }
    }
}
