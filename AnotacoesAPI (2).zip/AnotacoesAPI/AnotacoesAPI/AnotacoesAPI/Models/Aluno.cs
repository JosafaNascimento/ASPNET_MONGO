﻿using System;
using System.ComponentModel.DataAnnotations;

namespace AnotacoesAPI.Models
{
    public class Aluno
    {
        public Guid Id { get; set; }

        [Required]
        public string NomeAluno { get; set; }

        [Required]
        public string Conteudo { get; set; }

        [Required]
        public int Acessos { get; set; }
        

    }
}
